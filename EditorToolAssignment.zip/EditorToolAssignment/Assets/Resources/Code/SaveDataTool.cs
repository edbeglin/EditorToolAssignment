using UnityEditor;
using System.Collections.Generic;
using UnityEditor.EditorTools;
using UnityEngine;
using System.IO;

[EditorTool("Save Data Tool")]
class SaveDataTool : EditorTool
{
    // Sub-menu current state
    static bool subMenu_IsActive;
    static int subMenu_ActiveIndex;
    static string subMenu_ActiveName;
    static string subMenu_SelectedOptionName;

    // Sub-menu options and strings (user-editable variables)
    static bool[] subMenu_OptionToggles;
    static int subMenu_SelectedOptionToggle;
    static string[] subMenu_StringsToEdit;

    // [Bundles sub-menu only] Bundle item state
    static bool bundleItem_EditingItems;
    static bool[] bundleItem_Toggles;
    static string bundleItem_SetAmount;
    static int bundleItem_SelectedIndex;
    
    // Setup booleans (called when an option is selected in respective sub-menu)
    static bool setupData_Spaceship;
    static bool setupData_Currency;
    static bool setupData_Bundle;
    
    // Converted json data
    [SerializeField] private static Spaceships spaceshipsInJson = new Spaceships();
    [SerializeField] private static Powerups powerupsInJson = new Powerups();
    [SerializeField] private static Currencies currenciesInJson = new Currencies();
    [SerializeField] private static Bundles bundlesInJson = new Bundles();

    // Layout
    static int panelWidth = 300;
    static int spaceHeight = 10;

    // Called when this tool becomes active 
    public override void OnActivated()
    {
        SceneView.lastActiveSceneView.ShowNotification(new GUIContent("Entering Save Data Tool"), 0.1f);
    }

    // Called just before this tool is changed or deactivated
    public override void OnWillBeDeactivated()
    {
        SceneView.lastActiveSceneView.ShowNotification(new GUIContent("Exiting Save Data Tool"), 0.1f);
    }

    // GUI for tool is set up within this method
    public override void OnToolGUI(EditorWindow window)
    {
        Handles.BeginGUI();
        
        using (new GUILayout.HorizontalScope())
        {
            using (new GUILayout.VerticalScope(EditorStyles.helpBox))
            {
                // Always display path (e.g. Save Data Tool / Spaceships / Newbie Ship)
                CurrentPathLabel();

                // Always display contextual back button
                BackButton();

                // When not in a sub-menu (selected from top-level menu after entering tool)...
                if (!subMenu_IsActive)
                {
                    // Display buttons allowing user to enter various sub-menus
                    SubMenuButtons();
                }

                //When in a sub-menu...
                if (subMenu_IsActive)
                {
                    // When a data entry is not selected, display a message prompting user to select one
                    if (!IsAnOptionSelected())
                    {
                        Message_SelectEntry();
                    }

                    // Sub-menu methods
                    SubMenu0_Spaceships();
                    SubMenu1_Powerups();
                    SubMenu2_Currencies();
                    SubMenu3_Bundles();
                }
            }

            // Fills out remaining space in GUI
            GUILayout.FlexibleSpace();
        }

        Handles.EndGUI();
    }

    // Constantly displays the current path user has path taken through the GUI 
    // (e.g. Save Data Tool / Spaceships / Newbie Spaceship)
    void CurrentPathLabel()
    {
        string fullPath;

        // Get names of current sub-menu and selected option (if applicable)
        string toolName = ("Save Data Tool");
        string subMenu_ActiveName = GetSubMenuName();
        string subMenu_SelectedOptionName = GetSelectedOptionName();

        // If user is editing bundle items, also add " / Bundle Items" to the end of string
        if (bundleItem_EditingItems)
        {
            fullPath = (toolName + subMenu_ActiveName + subMenu_SelectedOptionName + " / Bundle Items");
        }
        else
        {
            fullPath = (toolName + subMenu_ActiveName + subMenu_SelectedOptionName);
        }

        // Display path as label in GUI
        GUILayout.Label(fullPath);
    }

    // If user is in a sub-menu, returns its name
    string GetSubMenuName()
    {
        if (!subMenu_IsActive)
        {
            return null;
        }
        else
        {
            string slash = " / ";
            return slash + subMenu_ActiveName;
        }
    }

    // If user has selected an option whilst in a sub-menu, returns name of option
    string GetSelectedOptionName()
    {
        if (!IsAnOptionSelected())
        {
            return null;
        }
        else
        {
            string slash = " / ";
            
            if (subMenu_ActiveIndex == 0)
            {
                string name = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].name;
                return slash + name;
            }
            else if (subMenu_ActiveIndex == 1)
            {
                string name = powerupsInJson.powerups[subMenu_SelectedOptionToggle].name;
                return slash + name;
            }
            else if (subMenu_ActiveIndex == 2)
            {
                string name = currenciesInJson.currencies[subMenu_SelectedOptionToggle].name;
                return slash + name;
            }
            else if (subMenu_ActiveIndex == 3)
            {
                string name = bundlesInJson.bundles[subMenu_SelectedOptionToggle].name;
                return slash + name;
            }
            else
            {
                return null;
            }
        }
    }

    // Back button contextually and persistently displays at the top of the GUI, and
    // changes functionality based on current state of GUI.
    void BackButton()
    {
        // Do not display back button if user is at top level of menus
        if (subMenu_IsActive)
        {
            if (GUILayout.Button("Back"))
            {
                // If an option in sub-menu is not selected, reset variables 
                if (!IsAnOptionSelected())
                {
                    subMenu_OptionToggles = new bool[0];
                    subMenu_StringsToEdit = new string[0];
                    subMenu_IsActive = false;
                }

                //If an option in sub-menu is selected, setup option toggle booleans
                if (IsAnOptionSelected())
                {
                    // If not in bundles sub-menu, or in bundles sub-menu not currently editing bundle items,
                    // setup boolean toggle for each available option in sub-menu.
                    if (subMenu_ActiveIndex != 3 || subMenu_ActiveIndex == 3 && !bundleItem_EditingItems)
                    {
                        subMenu_StringsToEdit = new string[0];

                        for (int i = 0; i < subMenu_OptionToggles.Length; i++)
                        {
                            subMenu_OptionToggles[i] = false;
                        }
                    }

                    // If in the bundles sub-menu and editing items, back button will return user to editing
                    // general bundle variables (asset, price) unrelated to items.
                    if (subMenu_ActiveIndex == 3 && bundleItem_EditingItems)
                    {
                        bundleItem_EditingItems = false;
                    }
                }
            }

            // Include space below back button to separate from rest of GUI below it
            GUILayout.Space(spaceHeight);
        }
    }

    // User can enter the various sub-menus using these buttons
    void SubMenuButtons()
    {
        if (GUILayout.Button("Spaceships"))
        {
            EnterSubMenu(0);
        }

        if (GUILayout.Button("Powerups"))
        {
            EnterSubMenu(1);
        }

        if (GUILayout.Button("Currencies"))
        {
            EnterSubMenu(2);
        }

        if (GUILayout.Button("Bundles"))
        {
            EnterSubMenu(3);
        }
    }

    // When a data entry is not selected, display a message prompting user to select one
    void Message_SelectEntry()
    {
        EditorGUILayout.HelpBox("Please select an entry below to begin manipulating it.", MessageType.Info);

        GUILayout.Space(spaceHeight);
    }

    // Prevents variables from going below zero in various sub-menus
    void CheckForNegativeValue()
    {
        string negativeNotif = "Negative value was set, reverting this value to 0.";

        if (subMenu_ActiveIndex == 1)
        {
            for (int i = 0; i < powerupsInJson.powerups.Length; i++)
            {
                if (powerupsInJson.powerups[i].amount < 0)
                {
                    Debug.Log(negativeNotif);
                    powerupsInJson.powerups[i].amount = 0;
                }
            }
        }

        if (subMenu_ActiveIndex == 2)
        {
            for (int i = 0; i < currenciesInJson.currencies.Length; i++)
            {
                if (currenciesInJson.currencies[i].amount < 0)
                {
                    Debug.Log(negativeNotif);
                    currenciesInJson.currencies[i].amount = 0;
                }
            }
        }

        if (subMenu_ActiveIndex == 3)
        {
            for (int i = 0; i < bundlesInJson.bundles[subMenu_SelectedOptionToggle].items.Count; i++)
            {
                if (bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[i].amount < 0)
                {
                    Debug.Log(negativeNotif);
                    bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[i].amount = 0;
                }
            }
        }
    }

    // When entering a sub-menu, the following occurs:

        // - Index of the selected menu is set as an int. This is used in many places such as SaveData().
        // - Sets name of sub-menu. This is used in a string telling the user their path through the GUI.
        // - Loads relevant json data to variables in this script.

    void EnterSubMenu(int subMenuIndex)
    {
        subMenu_ActiveIndex = subMenuIndex;

        if (subMenuIndex == 0)
        {
            subMenu_ActiveName = "Spaceships";

            string jsonToRead = File.ReadAllText(Application.dataPath + "/Resources/Data/SpaceshipsData.json");
            spaceshipsInJson = JsonUtility.FromJson<Spaceships>(jsonToRead);

            int l = spaceshipsInJson.spaceships.Length;
            subMenu_OptionToggles = new bool[l];
        }

        if (subMenuIndex == 1)
        {
            subMenu_ActiveName = "Powerups";

            string jsonToRead = File.ReadAllText(Application.dataPath + "/Resources/Data/PowerupsData.json");
            powerupsInJson = JsonUtility.FromJson<Powerups>(jsonToRead);

            int l = powerupsInJson.powerups.Length;
            subMenu_OptionToggles = new bool[l];
        }

        if (subMenuIndex == 2)
        {
            subMenu_ActiveName = "Currencies";

            string jsonToRead = File.ReadAllText(Application.dataPath + "/Resources/Data/CurrenciesData.json");
            currenciesInJson = JsonUtility.FromJson<Currencies>(jsonToRead);

            int l = currenciesInJson.currencies.Length;
            subMenu_OptionToggles = new bool[l];
        }

        if (subMenuIndex == 3)
        {
            subMenu_ActiveName = "Bundles";

            string jsonToRead = File.ReadAllText(Application.dataPath + "/Resources/Data/BundlesData.json");
            bundlesInJson = JsonUtility.FromJson<Bundles>(jsonToRead);

            int l = bundlesInJson.bundles.Length;
            subMenu_OptionToggles = new bool[l];
        }

        // Lastly, set user as currently in a sub-menu
        subMenu_IsActive = true;
    }

    void SubMenu0_Spaceships()
    {
        if (subMenu_ActiveIndex == 0) 
        { 
            // If user has not yet selected an option within sub-menu...
            if (!IsAnOptionSelected())
            {
                // Set up a boolean toggle for each option in this sub-menu
                for (int i = 0; i < subMenu_OptionToggles.Length; i++)
                {
                    EditorGUIUtility.labelWidth = panelWidth;

                    // Create an option toggle for each spaceship
                    string name = (spaceshipsInJson.spaceships[i].name);
                    string speed = ("     Speed = " + spaceshipsInJson.spaceships[i].speed);
                    string power = (", Power = " + spaceshipsInJson.spaceships[i].power);
                    
                    string fullString = (name + speed + power);

                    subMenu_OptionToggles[i] = EditorGUILayout.Toggle(fullString, subMenu_OptionToggles[i]);

                    // Display an image below each option toggle for each spaceship
                    string path = ("Assets/Resources/Images/" + spaceshipsInJson.spaceships[i].icon);
                    Texture tex = (Texture)AssetDatabase.LoadAssetAtPath(path, typeof(Texture));
                    GUILayout.Box(tex);
                }

                GUILayout.Space(spaceHeight);

                // Display button which allows user to create a new spaceship entry
                if (GUILayout.Button("Add a new spaceship entry"))
                {  
                    // Get the data of the last spaceship in current array, so its id can be used
                    int spaceshipCount = spaceshipsInJson.spaceships.Length -1; 
                    Spaceship lastSpaceship = spaceshipsInJson.spaceships[spaceshipCount];

                    // Create a new spaceship
                    Spaceship newSpaceship = new Spaceship();
                        
                        newSpaceship.id = (lastSpaceship.id +1);
                        newSpaceship.type = lastSpaceship.type;
                        newSpaceship.name = "New spaceship";
                        newSpaceship.icon = lastSpaceship.icon;
                        newSpaceship.speed = 0;
                        newSpaceship.power = 0;

                    // Create duplicate of 'spaceshipsInJson' array and populate it, but with one additional entry 
                    // to be used for newly created spaceship.
                    Spaceships appendedSpaceshipsInJson = new Spaceships();
                    appendedSpaceshipsInJson.spaceships = new Spaceship[spaceshipsInJson.spaceships.Length +1];

                    for (int i = 0; i < spaceshipsInJson.spaceships.Length; i++)
                    {
                        appendedSpaceshipsInJson.spaceships[i] = spaceshipsInJson.spaceships[i];
                    }

                    // Set created spaceship to newly added last entry in array
                    appendedSpaceshipsInJson.spaceships[appendedSpaceshipsInJson.spaceships.Length -1] = newSpaceship;
                    
                    // Convert new array to json
                    string appendedJsonString = JsonUtility.ToJson(appendedSpaceshipsInJson, true);

                    // Get path of current json
                    string path = (Application.dataPath + "/Resources/Data/SpaceshipsData.json");

                    // Save new array to json file
                    File.WriteAllText(path, appendedJsonString);

                    // Reload submenu, causing new spaceship to appear in GUI, and 'spaceshipsInJson' to be rebuilt
                    EnterSubMenu(0);
                }

                setupData_Spaceship = false;
            }

            // If user has selected an option within sub-menu...
            else
            {
                // Remind user to save their changes
                EditorGUILayout.HelpBox("Please click 'save entered variables' once you have finished adjusting variables.", MessageType.Info);

                GUILayout.Space(spaceHeight);

                // Display label which shows name and current data for selected spaceship entry
                string name = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].name;
                string speed = ("     Speed = " + spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].speed);
                string power = (", Power = " + spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].power);

                string fullString = (name + speed + power);
                GUILayout.Label(fullString);

                // Display selected spaceship entry's image
                string path = ("Assets/Resources/Images/" + spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].icon);
                Texture tex = (Texture)AssetDatabase.LoadAssetAtPath(path, typeof(Texture));
                GUILayout.Box(tex);

                GUILayout.Space(spaceHeight);
                
                // Create user-editable fields displaying spaceship entry's data
                GUILayout.Label("Name");
                subMenu_StringsToEdit[0] = EditorGUILayout.TextField(subMenu_StringsToEdit[0]);

                GUILayout.Label("Icon");
                subMenu_StringsToEdit[1] = EditorGUILayout.TextField(subMenu_StringsToEdit[1]);

                GUILayout.Label("Speed");
                subMenu_StringsToEdit[2] = EditorGUILayout.TextField(subMenu_StringsToEdit[2]);

                GUILayout.Label("Power");
                subMenu_StringsToEdit[3] = EditorGUILayout.TextField(subMenu_StringsToEdit[3]);

                GUILayout.Space(spaceHeight);

                // Display button which, when clicked, will save values entered in above fields to json file
                if (GUILayout.Button("Save entered variables"))
                {  
                    SaveData();
                }
            }
        }
    }

    void SubMenu1_Powerups()
    {
        if (subMenu_ActiveIndex == 1) 
        {
            // If an option has not yet been selected in this sub-menu...
            if (!IsAnOptionSelected())
            {
                for (int i = 0; i < subMenu_OptionToggles.Length; i++)
                {
                    EditorGUIUtility.labelWidth = panelWidth;

                    // Display names and amounts of each powerup
                    string name = (powerupsInJson.powerups[i].name);
                    string amount = ("     Current amount = " + powerupsInJson.powerups[i].amount);

                    string fullString = (name + amount);
                    subMenu_OptionToggles[i] = EditorGUILayout.Toggle(fullString, subMenu_OptionToggles[i]);
                    
                    // Display each powerup's image
                    string path = ("Assets/Resources/Images/" + powerupsInJson.powerups[i].icon);
                    Texture tex = (Texture)AssetDatabase.LoadAssetAtPath(path, typeof(Texture));
                    GUILayout.Box(tex);
                }
            }

            // If an option has been selected in this sub-menu...
            else
            {
                // Display name and amount of selected powerup
                string name = (powerupsInJson.powerups[subMenu_SelectedOptionToggle].name);
                string amount = ("     Current amount = " + powerupsInJson.powerups[subMenu_SelectedOptionToggle].amount);

                string fullString = (name + amount);
                GUILayout.Label(fullString);
                
                // Display powerup's image
                string path = ("Assets/Resources/Images/" + powerupsInJson.powerups[subMenu_SelectedOptionToggle].icon);
                Texture tex = (Texture)AssetDatabase.LoadAssetAtPath(path, typeof(Texture));
                GUILayout.Box(tex);

                EditorGUIUtility.labelWidth = panelWidth;

                GUILayout.Space(spaceHeight);

                // Increase amount in increments

                    GUILayout.Label("Increase amount by...");

                    if (GUILayout.Button("1"))
                    {  
                        powerupsInJson.powerups[subMenu_SelectedOptionToggle].amount += 1;
                        SaveData();
                    }
                    if (GUILayout.Button("10"))
                    {  
                        powerupsInJson.powerups[subMenu_SelectedOptionToggle].amount += 10;
                        SaveData();
                    }
                
                GUILayout.Space(spaceHeight);

                // Decrease amount in increments

                    GUILayout.Label("Decrease amount by...");

                    if (GUILayout.Button("1"))
                    {  
                        powerupsInJson.powerups[subMenu_SelectedOptionToggle].amount -= 1;
                        CheckForNegativeValue();
                        SaveData();
                    }
                    if (GUILayout.Button("10"))
                    {  
                        powerupsInJson.powerups[subMenu_SelectedOptionToggle].amount -= 10;
                        CheckForNegativeValue();
                        SaveData();
                    }
            }
        }
    }

    void SubMenu2_Currencies()
    {
        if (subMenu_ActiveIndex == 2) 
        {
            // If user has not yet selected an option within sub-menu...
            if (!IsAnOptionSelected())
            {
                for (int i = 0; i < subMenu_OptionToggles.Length; i++)
                {
                    // Set width for each toggle to allow full string to be read in GUI
                    EditorGUIUtility.labelWidth = panelWidth;

                    // Display an option toggle for each currency, including its name and current amount
                    string name = currenciesInJson.currencies[i].name;
                    string amount = ("     Current amount = " + currenciesInJson.currencies[i].amount);

                    string fullString = (name + amount);
                    subMenu_OptionToggles[i] = EditorGUILayout.Toggle(fullString, subMenu_OptionToggles[i]);

                    // Include space between each currency
                    GUILayout.Space(spaceHeight);
                }

                setupData_Currency = false;
            }

            // If user has selected an option within sub-menu...
            else
            {
                // Display name and current amount of selected currency
                string name = currenciesInJson.currencies[subMenu_SelectedOptionToggle].name;
                string amount = ("     Current amount = " + currenciesInJson.currencies[subMenu_SelectedOptionToggle].amount);
                
                string fullString = (name + amount);
                GUILayout.Label(fullString);

                GUILayout.Space(spaceHeight);

                // Display field where user can enter amount of currency they wish to set, add, or subtract
                GUILayout.Label("Enter amount...");
                subMenu_StringsToEdit[0] = EditorGUILayout.TextField(subMenu_StringsToEdit[0]);

                EditorGUIUtility.labelWidth = panelWidth;

                // Below buttons allow user to set, add, or subtract the amount entered in the above text field
                if (GUILayout.Button("Set to amount"))
                {  
                    if (int.TryParse(subMenu_StringsToEdit[0], out int value))
                    {
                        currenciesInJson.currencies[subMenu_SelectedOptionToggle].amount = value;
                        CheckForNegativeValue();
                        SaveData();
                    }
                    else
                    {
                        IntegerWarning();
                    }
                }
                if (GUILayout.Button("Add amount"))
                {  
                    if (int.TryParse(subMenu_StringsToEdit[0], out int value))
                    {
                        currenciesInJson.currencies[subMenu_SelectedOptionToggle].amount += value;
                        CheckForNegativeValue();
                        SaveData();
                    }
                    else
                    {
                        IntegerWarning();
                    }
                }
                if (GUILayout.Button("Subtract amount"))
                {
                    if (int.TryParse(subMenu_StringsToEdit[0], out int value))
                    {
                        currenciesInJson.currencies[subMenu_SelectedOptionToggle].amount -= value;
                        CheckForNegativeValue();
                        SaveData();
                    }
                    else
                    {
                        IntegerWarning();
                    }
                }
            }
        }
    }

    void SubMenu3_Bundles()
    {
        if (subMenu_ActiveIndex == 3) 
        {
            // If user has not yet selected an option within sub-menu...
            if (!IsAnOptionSelected())
            {
                for (int i = 0; i < subMenu_OptionToggles.Length; i++)
                {
                    EditorGUIUtility.labelWidth = panelWidth;

                    // Create an option toggle for each bundle entry
                    string name = (bundlesInJson.bundles[i].name);
                    subMenu_OptionToggles[i] = EditorGUILayout.Toggle(name, subMenu_OptionToggles[i]);

                    // Display asset image for each bundle entry
                    string path = ("Assets/Resources/Images/" + bundlesInJson.bundles[i].asset);
                    Texture tex = (Texture)AssetDatabase.LoadAssetAtPath(path, typeof(Texture));
                    GUILayout.Box(tex);
                }

                setupData_Bundle = false;
            }

            // If user has selected an option within sub-menu...
            else
            {
                // If user is not editing bundle items, and is instead viewing general bundle data (asset, price)...
                if (!bundleItem_EditingItems)
                {
                    // Remind user to save their changes
                    EditorGUILayout.HelpBox("Please click 'save entered variables' once you have finished adjusting variables.", MessageType.Info);

                    GUILayout.Space(spaceHeight);

                    // Display name of bundle near top of GUI
                    string name = (bundlesInJson.bundles[subMenu_SelectedOptionToggle].name);
                    GUILayout.Label(name);

                    // Display bundle's asset image
                    string path = ("Assets/Resources/Images/" + bundlesInJson.bundles[subMenu_SelectedOptionToggle].asset);
                    Texture tex = (Texture)AssetDatabase.LoadAssetAtPath(path, typeof(Texture));
                    GUILayout.Box(tex);
                    
                    // Create user-editable fields displaying bundle entry's data
                    GUILayout.Label("Name");
                    subMenu_StringsToEdit[0] = EditorGUILayout.TextField(subMenu_StringsToEdit[0]);

                    GUILayout.Label("Asset");
                    subMenu_StringsToEdit[1] = EditorGUILayout.TextField(subMenu_StringsToEdit[1]);

                    GUILayout.Label("Price");
                    subMenu_StringsToEdit[2] = EditorGUILayout.TextField(subMenu_StringsToEdit[2]);

                    GUILayout.Space(spaceHeight);

                    // Display button which, when clicked, will save values entered in above fields to json file
                    if (GUILayout.Button("Save entered variables"))
                    {  
                        SaveData();
                    }

                    GUILayout.Space(spaceHeight);

                    // Allow user to enter menu via button at bottom of GUI specifically for editing bundle items 
                    GUILayout.Label("Bundle items");

                    if (GUILayout.Button("Edit items in this bundle"))
                    { 
                        // Resets item variables upon entry
                        bundleItem_Toggles = new bool[bundlesInJson.bundles[subMenu_SelectedOptionToggle].items.Count];
                        bundleItem_SetAmount = "";

                        // Set user as editing bundle items
                        bundleItem_EditingItems = true;
                    }
                }

                //If user is editing bundle items...
                else
                {
                    // Display name of bundle near top of GUI
                    GUILayout.Label(bundlesInJson.bundles[subMenu_SelectedOptionToggle].name + " Bundle Items");

                    GUILayout.Space(spaceHeight);

                    // When a data entry is not selected, display a message prompting user to select one
                    if (!IsAnItemSelected())
                    {
                        Message_SelectEntry();
                    }

                    for (int i = 0; i < bundlesInJson.bundles[subMenu_SelectedOptionToggle].items.Count; i++)
                    {
                        EditorGUIUtility.labelWidth = panelWidth;

                        // Display an option toggle for each bundle item, including its id and current amount
                        string itemId = "Item ID = " + bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[i].itemId;
                        string amount = (",     Current amount = " + bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[i].amount);

                        string fullString = (itemId + amount);
                        bundleItem_Toggles[i] = EditorGUILayout.Toggle(fullString, bundleItem_Toggles[i]);
                    
                        GUILayout.Space(spaceHeight);
                    }

                    // Sets all other bundle item toggles to false when one is set true
                    DisableOtherItemToggles();

                    // Display field where user can enter amount of bundle item they wish to set, add, or subtract
                    GUILayout.Label("Enter amount...");
                    bundleItem_SetAmount = EditorGUILayout.TextField(bundleItem_SetAmount);

                    EditorGUIUtility.labelWidth = panelWidth;

                    // Below buttons allow user to set, add, or subtract the amount entered in the above text field
                    if (GUILayout.Button("Set to amount"))
                    {  
                        if (IsAnItemSelected())
                        {
                            if (int.TryParse(bundleItem_SetAmount, out int value))
                            {
                                bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[bundleItem_SelectedIndex].amount = value;
                                CheckForNegativeValue();
                                SaveData();
                            }
                            else
                            {
                                IntegerWarning();
                            }
                        }
                    }
                    if (GUILayout.Button("Add amount"))
                    {  
                        if (IsAnItemSelected())
                        {
                            if (int.TryParse(bundleItem_SetAmount, out int value))
                            {
                                bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[bundleItem_SelectedIndex].amount += value;
                                CheckForNegativeValue();
                                SaveData();
                            }
                            else
                            {
                                IntegerWarning();
                            }
                        }
                    }
                    if (GUILayout.Button("Subtract amount"))
                    {
                        if (IsAnItemSelected())
                        {
                            if (int.TryParse(bundleItem_SetAmount, out int value))
                            {
                                bundlesInJson.bundles[subMenu_SelectedOptionToggle].items[bundleItem_SelectedIndex].amount -= value;
                                CheckForNegativeValue();
                                SaveData();
                            }
                            else
                            {
                                IntegerWarning();
                            }
                        }
                    }
                }
            }
        }
    }

    // Sets all other bundle item toggles to false when one is set true
    void DisableOtherItemToggles()
    {
        if (bundleItem_Toggles != null)
        {
            for (int a = 0; a < bundleItem_Toggles.Length; a++)
            {
                if (bundleItem_SelectedIndex != a)
                {
                    if (bundleItem_Toggles[a])
                    {
                        bundleItem_SelectedIndex = a;

                        for (int b = 0; b < bundleItem_Toggles.Length; b++)
                        {
                            if (a != b)
                            {
                                bundleItem_Toggles[b] = false;
                            }
                        }
                    }
                }
            }
        }
    }

    // Returns true if a bundle item is selected
    bool IsAnItemSelected()
    {
        if (bundleItem_Toggles != null)
        {
            for (int i = 0; i < bundleItem_Toggles.Length; i++)
            {
                if (bundleItem_Toggles[i])
                {
                    bundleItem_SelectedIndex = i;
                    return true;
                }
            }
            return false;
        }
        else
        {
            return false;
        }
    }

    // Makes sure entered string begins with $ sign
    bool IsDollarValue(string input)
    {
        if (input[0] == '$')
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Creates arrays of options to select and strings to edit based on which sub-menu user is currently in.
    // These arrays must be set up here, as if they are included in OnToolGUI(), they will not remain static.
    bool IsAnOptionSelected()
    {
        if (subMenu_OptionToggles != null)
        {
            for (int i = 0; i < subMenu_OptionToggles.Length; i++)
            {
                if (subMenu_OptionToggles[i])
                {
                    subMenu_SelectedOptionToggle = i;

                    if (subMenu_ActiveIndex == 0)
                    {
                        if (!setupData_Spaceship)
                        {
                            subMenu_StringsToEdit = new string[4];

                            subMenu_StringsToEdit[0] = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].name;
                            subMenu_StringsToEdit[1] = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].icon;
                            subMenu_StringsToEdit[2] = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].speed.ToString();
                            subMenu_StringsToEdit[3] = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle].power.ToString();

                            setupData_Spaceship = true;
                        }
                    }

                    if (subMenu_ActiveIndex == 2)
                    {
                        if (!setupData_Currency)
                        {
                            subMenu_StringsToEdit = new string[1];

                            setupData_Currency = true;
                        }
                    }

                    if (subMenu_ActiveIndex == 3)
                    {
                        if (!setupData_Bundle)
                        {
                            subMenu_StringsToEdit = new string[3];

                            subMenu_StringsToEdit[0] = bundlesInJson.bundles[subMenu_SelectedOptionToggle].name;
                            subMenu_StringsToEdit[1] = bundlesInJson.bundles[subMenu_SelectedOptionToggle].asset;
                            subMenu_StringsToEdit[2] = bundlesInJson.bundles[subMenu_SelectedOptionToggle].price;

                            setupData_Bundle = true;
                        }
                    }

                    return true;
                }
            }
            return false;
        }
        else
        {
            return false;
        }
    }

    void IntegerWarning()
    {
        string warningText = "Please enter an integer.";
        Debug.Log(warningText);
    }

    // Contextually saves data based on open sub-menu
    public void SaveData()
    {
        string path;
        string amendedJson;

        if (subMenu_ActiveIndex == 0)
        {
            Spaceship spaceship = spaceshipsInJson.spaceships[subMenu_SelectedOptionToggle];

            if (subMenu_StringsToEdit[0] != "")
            {
                spaceship.name = subMenu_StringsToEdit[0];
            }
            else
            {
                Debug.Log("Cannot save name as string is empty.");
            }

            if (subMenu_StringsToEdit[1].Contains(".png"))
            {
                spaceship.icon = subMenu_StringsToEdit[1];
            }
            else
            {
                Debug.Log("Cannot save icon as string is not a valid .png file.");
            }

            if (int.TryParse(subMenu_StringsToEdit[2], out int value))
            {
                spaceship.speed = value;
            }
            else
            {
                IntegerWarning();
            }

            if (int.TryParse(subMenu_StringsToEdit[3], out int value2))
            {
                spaceship.power = value2;
            }
            else
            { 
                IntegerWarning();
            }

            // Get path to relevant json data
            path = (Application.dataPath + "/Resources/Data/SpaceshipsData.json");
                
            // Second argument makes sure string is formatted in "prettyprint"
            amendedJson = JsonUtility.ToJson(spaceshipsInJson, true);
        }

        else if (subMenu_ActiveIndex == 1)
        {
            // Get path to relevant json data
            path = (Application.dataPath + "/Resources/Data/PowerupsData.json");
            
            // Convert string to json, second argument makes sure string is formatted in "prettyprint"
            amendedJson = JsonUtility.ToJson(powerupsInJson, true);
        }

        else if (subMenu_ActiveIndex == 2)
        {
            // Get path to relevant json data
            path = (Application.dataPath + "/Resources/Data/CurrenciesData.json");
            
            // Second argument makes sure string is formatted in "prettyprint"
            amendedJson = JsonUtility.ToJson(currenciesInJson, true);
        }

        else if (subMenu_ActiveIndex == 3)
        {
            Bundle currentBundle = bundlesInJson.bundles[subMenu_SelectedOptionToggle];

            if (subMenu_StringsToEdit[0] != "")
            {
                currentBundle.name = subMenu_StringsToEdit[0];
            }
            else
            {
                Debug.Log("Cannot save name as string is empty.");
            }

            if (subMenu_StringsToEdit[1].Contains(".png"))
            {
                currentBundle.asset = subMenu_StringsToEdit[1];
            }
            else
            {
                Debug.Log("Cannot save asset as string is empty.");
            }

            if (IsDollarValue(subMenu_StringsToEdit[2]))
            {
                currentBundle.price = subMenu_StringsToEdit[2];
            }
            else
            {
                Debug.Log("Please enter a price in the format $0.00.");
            }

            // Get path of current bundle data
            path = (Application.dataPath + "/Resources/Data/BundlesData.json");
                
            // Convert string to json, second argument makes sure string is formatted in "prettyprint"
            amendedJson = JsonUtility.ToJson(bundlesInJson, true);
        }

        else
        {
            path = null;
            amendedJson = null;
        }

        // Write amended json to path 
        File.WriteAllText(path, amendedJson);
    }
}

[System.Serializable]
public class Spaceships
{
    public Spaceship[] spaceships;
}

[System.Serializable]
public class Spaceship
{
    public int id;
    public string type;
    public string name;
    public string icon;
    public int speed;
    public int power;
}

[System.Serializable]
public class Powerups
{
    public Powerup[] powerups;
}

[System.Serializable]
public class Powerup
{
    public int id;
    public string type;
    public string name;
    public string icon;
    public string stat;
    public int amount;
}

[System.Serializable]
public class Currencies
{
    public Currency[] currencies;
}

[System.Serializable]
public class Currency
{
    public int id;
    public string type;
    public string name;
    public int amount;
}

[System.Serializable]
public class Bundles
{
    public Bundle[] bundles;
}

[System.Serializable]
public class Bundle
{
    public int id;
    public string type;
    public string name;
    public string asset;
    public string price;
    public List<BundleItems> items;
}

[System.Serializable]
public class BundleItems
{
    public int itemId;
    public int amount;
}